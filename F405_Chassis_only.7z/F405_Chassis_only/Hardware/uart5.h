#ifndef __UART5_H__
#define __UART5_H__

void UART5_Configuration(void);
#define GYRO_BUF_SIZE 11

#endif
