#ifndef __USART2_H__
#define __USART2_H__
#define GYRO_BUF_SIZE 18
#define PC_SENDBUF_SIZE 16    //20
#define PC_RECVBUF_SIZE 9
void USART2_Configuration(void);

#endif
