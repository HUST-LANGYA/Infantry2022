#ifndef GPIO_H
#define GPIO_H

void My_GPIO_Init(void);

#endif
